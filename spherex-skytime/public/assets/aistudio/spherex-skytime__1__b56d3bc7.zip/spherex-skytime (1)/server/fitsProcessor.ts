import zlib from 'node:zlib';
import type {
  FitsHeaderSummary,
  FitsInspectResponse,
  FitsPhotometrySummary,
  FitsStats,
} from '../src/types/spherex.ts';

interface ParsedHdu {
  extname: string;
  bitpix: number;
  naxis: number;
  dims: number[];
  cards: string[];
  headerMap: Map<string, string>;
  dataOffset: number;
  dataBytes: number;
}

interface CachedFits {
  buffer: Buffer;
  hdus: ParsedHdu[];
  fetchedAt: number;
}

export const PER_OBSERVATION_TIMEOUT_MS = 30_000;

const fitsCache = new Map<string, CachedFits>();
const inspectCache = new Map<string, FitsInspectResponse>();
const inFlightFetches = new Map<string, Promise<{ cached: CachedFits; cutoutUrl: string }>>();
const MAX_FITS_CACHE = 300;
const MAX_INSPECT_CACHE = 400;

export class FitsValidationError extends Error {
  readonly code: 'INVALID_URL' | 'HTTP_ERROR' | 'HTML_RESPONSE' | 'INVALID_FITS' | 'TIMEOUT';
  readonly retryable: boolean;

  constructor(
    message: string,
    code: 'INVALID_URL' | 'HTTP_ERROR' | 'HTML_RESPONSE' | 'INVALID_FITS' | 'TIMEOUT',
    retryable = false
  ) {
    super(message);
    this.name = 'FitsValidationError';
    this.code = code;
    this.retryable = retryable;
  }
}

function isAllowedIrsaUrl(urlStr: string): boolean {
  try {
    const u = new URL(urlStr);
    return u.protocol === 'https:' && u.hostname.endsWith('irsa.ipac.caltech.edu');
  } catch {
    return false;
  }
}

function parseHeaderCard(card: string): { key: string; value: string } | null {
  if (card.startsWith('COMMENT') || card.startsWith('HISTORY') || card.startsWith('END     ')) {
    return null;
  }
  if (card.startsWith('HIERARCH ')) {
    const eqIdx = card.indexOf('=');
    if (eqIdx === -1) return null;
    const key = card.slice(0, eqIdx).trim();
    let valPart = card.slice(eqIdx + 1);
    const slashIdx = valPart.indexOf('/');
    if (slashIdx !== -1 && !valPart.trim().startsWith("'")) {
      valPart = valPart.slice(0, slashIdx);
    }
    return { key, value: valPart.trim().replace(/^'|'$/g, '').trim() };
  }
  if (card[8] === '=' && card[9] === ' ') {
    const key = card.slice(0, 8).trim();
    let valPart = card.slice(10);
    if (valPart.trim().startsWith("'")) {
      const m = valPart.match(/'([^']*)'/);
      return { key, value: m ? m[1].trim() : '' };
    }
    const slashIdx = valPart.indexOf('/');
    if (slashIdx !== -1) valPart = valPart.slice(0, slashIdx);
    return { key, value: valPart.trim() };
  }
  return null;
}

export function parseFitsHdus(buf: Buffer): ParsedHdu[] {
  const hdus: ParsedHdu[] = [];
  let offset = 0;

  while (offset + 2880 <= buf.length) {
    const cards: string[] = [];
    const headerMap = new Map<string, string>();
    let foundEnd = false;

    while (offset + 2880 <= buf.length) {
      const block = buf.subarray(offset, offset + 2880).toString('ascii');
      offset += 2880;
      for (let i = 0; i < 36; i++) {
        const card = block.slice(i * 80, (i + 1) * 80);
        cards.push(card);
        const parsed = parseHeaderCard(card);
        if (parsed) headerMap.set(parsed.key, parsed.value);
        if (card.startsWith('END     ')) {
          foundEnd = true;
          break;
        }
      }
      if (foundEnd) break;
    }

    if (!foundEnd) break;

    const bitpix = Number(headerMap.get('BITPIX') || 0);
    const naxis = Number(headerMap.get('NAXIS') || 0);
    const dims: number[] = [];
    for (let a = 1; a <= naxis; a++) {
      dims.push(Number(headerMap.get(`NAXIS${a}`) || 0));
    }
    const pcount = Number(headerMap.get('PCOUNT') || 0);
    const gcount = Number(headerMap.get('GCOUNT') || 1);

    let dataBytes = 0;
    if (naxis > 0) {
      const npix = dims.reduce((acc, d) => acc * d, 1);
      dataBytes = (Math.abs(bitpix) / 8) * gcount * (pcount + npix);
    }

    const extname = headerMap.get('EXTNAME') || (hdus.length === 0 ? 'PRIMARY' : `HDU_${hdus.length}`);
    hdus.push({
      extname,
      bitpix,
      naxis,
      dims,
      cards,
      headerMap,
      dataOffset: offset,
      dataBytes,
    });

    const padded = Math.ceil(dataBytes / 2880) * 2880;
    offset += padded;
  }

  return hdus;
}

function readFloat32Array(buf: Buffer, hdu: ParsedHdu): Float32Array {
  const count = hdu.dims[0] * hdu.dims[1];
  if (hdu.dataOffset + count * 4 > buf.length) {
    throw new FitsValidationError(
      'FITS IMAGE HDU data section is truncated or incomplete.',
      'INVALID_FITS',
      true
    );
  }
  const out = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    out[i] = buf.readFloatBE(hdu.dataOffset + i * 4);
  }
  return out;
}

function readInt32Array(buf: Buffer, hdu: ParsedHdu): Int32Array {
  const count = hdu.dims[0] * hdu.dims[1];
  if (hdu.dataOffset + count * 4 > buf.length) {
    throw new FitsValidationError(
      'FITS FLAGS HDU data section is truncated or incomplete.',
      'INVALID_FITS',
      true
    );
  }
  const out = new Int32Array(count);
  for (let i = 0; i < count; i++) {
    out[i] = buf.readInt32BE(hdu.dataOffset + i * 4);
  }
  return out;
}

export function validateFitsResponseAndParse(
  status: number,
  contentType: string,
  buffer: Buffer
): ParsedHdu[] {
  if (status < 200 || status >= 300) {
    const retryable = [429, 500, 502, 503, 504].includes(status);
    throw new FitsValidationError(
      `IRSA cutout service returned HTTP ${status}.`,
      'HTTP_ERROR',
      retryable
    );
  }

  const ct = contentType.toLowerCase();
  const textPrefix = buffer.subarray(0, 64).toString('utf8').trimStart().toLowerCase();
  if (
    ct.includes('text/html') ||
    ct.includes('application/xhtml') ||
    textPrefix.startsWith('<!doctype') ||
    textPrefix.startsWith('<html')
  ) {
    throw new FitsValidationError(
      'Archive returned an HTML page instead of FITS observation data.',
      'HTML_RESPONSE',
      true
    );
  }

  if (ct.includes('application/json') || textPrefix.startsWith('{')) {
    throw new FitsValidationError(
      'Archive returned JSON text instead of binary FITS data.',
      'INVALID_FITS',
      false
    );
  }

  const magic = buffer.subarray(0, 9).toString('ascii');
  if (buffer.length < 2880 || !magic.startsWith('SIMPLE  =')) {
    throw new FitsValidationError(
      'Response payload is missing a valid FITS SIMPLE header.',
      'INVALID_FITS',
      false
    );
  }

  const hdus = parseFitsHdus(buffer);
  const imageHdu =
    hdus.find((h) => h.extname === 'IMAGE' && h.naxis === 2) ||
    hdus.find((h) => h.naxis === 2);

  if (!imageHdu || imageHdu.dims[0] <= 0 || imageHdu.dims[1] <= 0) {
    throw new FitsValidationError(
      'FITS file does not contain a valid 2D science IMAGE extension.',
      'INVALID_FITS',
      false
    );
  }

  if (imageHdu.dataOffset + imageHdu.dataBytes > buffer.length) {
    throw new FitsValidationError(
      'FITS IMAGE extension bytes are truncated.',
      'INVALID_FITS',
      true
    );
  }

  return hdus;
}

async function fetchFitsWithBudget(url: string, budgetMs = PER_OBSERVATION_TIMEOUT_MS): Promise<{
  buffer: Buffer;
  hdus: ParsedHdu[];
}> {
  const deadline = Date.now() + budgetMs;
  let lastError: FitsValidationError | null = null;

  for (let attempt = 1; attempt <= 2; attempt++) {
    const remaining = deadline - Date.now();
    if (remaining <= 500) {
      throw new FitsValidationError(
        'Observation retrieval exceeded the 30-second timeout.',
        'TIMEOUT',
        false
      );
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), remaining);

    try {
      const resp = await fetch(url, { signal: controller.signal });
      const contentType = resp.headers.get('content-type') || '';
      const buffer = Buffer.from(await resp.arrayBuffer());
      clearTimeout(timer);

      const hdus = validateFitsResponseAndParse(resp.status, contentType, buffer);
      return { buffer, hdus };
    } catch (err) {
      clearTimeout(timer);
      if (err instanceof FitsValidationError) {
        lastError = err;
        if (err.retryable && attempt < 2 && deadline - Date.now() > 2000) {
          await new Promise((r) => setTimeout(r, 600));
          continue;
        }
        throw err;
      }
      if (err instanceof DOMException && err.name === 'AbortError') {
        throw new FitsValidationError(
          'Observation retrieval timed out after 30 seconds.',
          'TIMEOUT',
          false
        );
      }
      lastError = new FitsValidationError(
        err instanceof Error ? err.message : 'Network error fetching FITS cutout.',
        'HTTP_ERROR',
        true
      );
      if (attempt < 2 && deadline - Date.now() > 2000) {
        await new Promise((r) => setTimeout(r, 600));
        continue;
      }
      throw lastError;
    }
  }

  throw (
    lastError ||
    new FitsValidationError('Failed to fetch valid FITS cutout from IRSA.', 'HTTP_ERROR', false)
  );
}

export async function fetchCutoutFits(
  accessUrl: string,
  raDeg: number,
  decDeg: number,
  sizeDeg = 0.08
): Promise<{ cached: CachedFits; cutoutUrl: string }> {
  if (!isAllowedIrsaUrl(accessUrl)) {
    throw new FitsValidationError(
      'Only official NASA/IPAC IRSA FITS URLs are permitted.',
      'INVALID_URL',
      false
    );
  }

  const clampedSize = Math.min(Math.max(sizeDeg, 0.02), 0.25);
  const cutoutUrl = `${accessUrl}?center=${raDeg.toFixed(6)},${decDeg.toFixed(6)}&size=${clampedSize.toFixed(4)}`;

  const existing = fitsCache.get(cutoutUrl);
  if (existing) {
    return { cached: existing, cutoutUrl };
  }

  const inflight = inFlightFetches.get(cutoutUrl);
  if (inflight) {
    return inflight;
  }

  const task = (async () => {
    const { buffer, hdus } = await fetchFitsWithBudget(cutoutUrl, PER_OBSERVATION_TIMEOUT_MS);

    if (fitsCache.size >= MAX_FITS_CACHE) {
      const oldestKey = fitsCache.keys().next().value;
      if (oldestKey) fitsCache.delete(oldestKey);
    }
    const entry: CachedFits = { buffer, hdus, fetchedAt: Date.now() };
    fitsCache.set(cutoutUrl, entry);
    return { cached: entry, cutoutUrl };
  })();

  inFlightFetches.set(cutoutUrl, task);
  try {
    return await task;
  } finally {
    inFlightFetches.delete(cutoutUrl);
  }
}

export async function buildSingleImageFits(
  accessUrl: string,
  raDeg: number,
  decDeg: number,
  sizeDeg = 0.08
): Promise<Buffer> {
  const { cached } = await fetchCutoutFits(accessUrl, raDeg, decDeg, sizeDeg);
  const imageHdu =
    cached.hdus.find((h) => h.extname === 'IMAGE') || cached.hdus.find((h) => h.naxis === 2);
  if (!imageHdu) {
    throw new FitsValidationError(
      'No 2D science IMAGE extension found in FITS cutout.',
      'INVALID_FITS',
      false
    );
  }

  const keepKeys = new Set([
    'BITPIX',
    'NAXIS',
    'NAXIS1',
    'NAXIS2',
    'BUNIT',
    'CTYPE1',
    'CTYPE2',
    'CRVAL1',
    'CRVAL2',
    'CRPIX1',
    'CRPIX2',
    'PC1_1',
    'PC1_2',
    'PC2_1',
    'PC2_2',
    'CD1_1',
    'CD1_2',
    'CD2_1',
    'CD2_2',
    'CDELT1',
    'CDELT2',
    'EQUINOX',
    'RADESYS',
    'DATE-OBS',
    'MJD-OBS',
    'DETECTOR',
  ]);

  const outCards: string[] = [];
  const formatCard = (str: string) => str.padEnd(80, ' ').slice(0, 80);
  outCards.push(formatCard('SIMPLE  =                    T / Standard FITS primary image extracted from MEF'));

  for (const card of imageHdu.cards) {
    const key = card.slice(0, 8).trim();
    if (keepKeys.has(key)) {
      outCards.push(formatCard(card));
    }
  }
  outCards.push(formatCard('END'));

  while (outCards.length % 36 !== 0) {
    outCards.push(' '.repeat(80));
  }

  const headerBuf = Buffer.from(outCards.join(''), 'ascii');
  const rawImageBuf = cached.buffer.subarray(
    imageHdu.dataOffset,
    imageHdu.dataOffset + imageHdu.dataBytes
  );
  const paddedDataLen = Math.ceil(rawImageBuf.length / 2880) * 2880;
  const dataBuf = Buffer.alloc(paddedDataLen);
  rawImageBuf.copy(dataBuf);

  return Buffer.concat([headerBuf, dataBuf]);
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type: string, data: Buffer): Buffer {
  const typeBuf = Buffer.from(type, 'ascii');
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(data.length, 0);
  const crcInput = Buffer.concat([typeBuf, data]);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(crcInput), 0);
  return Buffer.concat([lenBuf, typeBuf, data, crcBuf]);
}

function encodeRgbPng(width: number, height: number, rgb: Uint8Array): Buffer {
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 2;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const stride = width * 3 + 1;
  const raw = Buffer.alloc(stride * height);
  for (let y = 0; y < height; y++) {
    const rowStart = y * stride;
    raw[rowStart] = 0;
    raw.set(rgb.subarray(y * width * 3, (y + 1) * width * 3), rowStart + 1);
  }

  const compressed = zlib.deflateSync(raw);
  return Buffer.concat([
    signature,
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', compressed),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

function applyColormap(
  t: number,
  colormap: 'infrared' | 'viridis' | 'grayscale' | 'cool'
): [number, number, number] {
  const x = Math.min(1, Math.max(0, t));
  if (colormap === 'grayscale') {
    const v = Math.round(x * 255);
    return [v, v, v];
  }
  if (colormap === 'cool') {
    const r = Math.round(255 * Math.pow(x, 2.1));
    const g = Math.round(255 * (0.12 + 0.88 * Math.pow(x, 1.15)));
    const b = Math.round(255 * (0.22 + 0.78 * Math.pow(x, 0.7)));
    return [Math.min(255, r), Math.min(255, g), Math.min(255, b)];
  }
  if (colormap === 'viridis') {
    const r = Math.round(255 * Math.min(1, Math.max(0, -0.35 + 1.35 * x * x)));
    const g = Math.round(255 * Math.min(1, Math.max(0, 0.05 + 0.9 * Math.pow(x, 0.85))));
    const b = Math.round(
      255 * Math.min(1, Math.max(0, 0.35 + 0.45 * Math.sin(x * Math.PI * 0.85)))
    );
    return [r, g, b];
  }
  if (x < 0.25) {
    const u = x / 0.25;
    return [Math.round(8 + u * 26), Math.round(14 + u * 22), Math.round(32 + u * 54)];
  }
  if (x < 0.6) {
    const u = (x - 0.25) / 0.35;
    return [Math.round(34 + u * 165), Math.round(36 + u * 58), Math.round(86 - u * 42)];
  }
  if (x < 0.88) {
    const u = (x - 0.6) / 0.28;
    return [Math.round(199 + u * 52), Math.round(94 + u * 115), Math.round(44 + u * 40)];
  }
  const u = (x - 0.88) / 0.12;
  return [Math.round(251 + u * 4), Math.round(209 + u * 46), Math.round(84 + u * 171)];
}

function worldToPixel(
  raDeg: number,
  decDeg: number,
  crval1: number,
  crval2: number,
  crpix1: number,
  crpix2: number,
  pc: [number, number, number, number]
): { x: number; y: number } | null {
  const deg2rad = Math.PI / 180;
  const alpha = raDeg * deg2rad;
  const delta = decDeg * deg2rad;
  const alpha0 = crval1 * deg2rad;
  const delta0 = crval2 * deg2rad;

  const cosD = Math.cos(delta);
  const sinD = Math.sin(delta);
  const cosD0 = Math.cos(delta0);
  const sinD0 = Math.sin(delta0);
  const dAlpha = alpha - alpha0;

  const denom = sinD * sinD0 + cosD * cosD0 * Math.cos(dAlpha);
  if (denom <= 0) return null;

  const xiDeg = (cosD * Math.sin(dAlpha)) / denom / deg2rad;
  const etaDeg = (sinD * cosD0 - cosD * sinD0 * Math.cos(dAlpha)) / denom / deg2rad;

  const [pc11, pc12, pc21, pc22] = pc;
  const det = pc11 * pc22 - pc12 * pc21;
  if (Math.abs(det) < 1e-18) return null;

  const dx = (pc22 * xiDeg - pc12 * etaDeg) / det;
  const dy = (-pc21 * xiDeg + pc11 * etaDeg) / det;

  return {
    x: crpix1 - 1 + dx,
    y: crpix2 - 1 + dy,
  };
}

export async function inspectAndRenderFits(params: {
  accessUrl: string;
  raDeg: number;
  decDeg: number;
  sizeDeg?: number;
  stretch?: 'asinh' | 'log' | 'linear';
  subtractZodi?: boolean;
  colormap?: 'infrared' | 'viridis' | 'grayscale' | 'cool';
}): Promise<FitsInspectResponse> {
  const stretch = params.stretch || 'asinh';
  const subtractZodi = params.subtractZodi ?? true;
  const colormap = params.colormap || 'infrared';
  const sizeDeg = params.sizeDeg ?? 0.08;

  const inspectKey = `${params.accessUrl}|${params.raDeg.toFixed(5)}|${params.decDeg.toFixed(5)}|${sizeDeg}|${stretch}|${subtractZodi}|${colormap}`;
  const cachedResp = inspectCache.get(inspectKey);
  if (cachedResp) {
    return cachedResp;
  }

  const { cached, cutoutUrl } = await fetchCutoutFits(
    params.accessUrl,
    params.raDeg,
    params.decDeg,
    sizeDeg
  );

  const imageHdu =
    cached.hdus.find((h) => h.extname === 'IMAGE' && h.naxis === 2) ||
    cached.hdus.find((h) => h.naxis === 2);

  if (!imageHdu || imageHdu.naxis !== 2) {
    throw new FitsValidationError(
      'Could not locate 2D IMAGE HDU in SPHEREx MEF file.',
      'INVALID_FITS',
      false
    );
  }

  const width = imageHdu.dims[0];
  const height = imageHdu.dims[1];
  const imageArr = readFloat32Array(cached.buffer, imageHdu);

  const zodiHdu = cached.hdus.find((h) => h.extname === 'ZODI');
  const zodiArr =
    zodiHdu && zodiHdu.dims[0] === width && zodiHdu.dims[1] === height
      ? readFloat32Array(cached.buffer, zodiHdu)
      : null;

  const varHdu = cached.hdus.find((h) => h.extname === 'VARIANCE');
  const varArr =
    varHdu && varHdu.dims[0] === width && varHdu.dims[1] === height
      ? readFloat32Array(cached.buffer, varHdu)
      : null;

  const flagsHdu = cached.hdus.find((h) => h.extname === 'FLAGS');
  const flagsArr =
    flagsHdu && flagsHdu.dims[0] === width && flagsHdu.dims[1] === height
      ? readInt32Array(cached.buffer, flagsHdu)
      : null;

  const signal = new Float32Array(width * height);
  const validValues: number[] = [];
  let flaggedPixels = 0;

  for (let i = 0; i < width * height; i++) {
    const raw = imageArr[i];
    const z = zodiArr ? zodiArr[i] : 0;
    const val = subtractZodi && zodiArr && Number.isFinite(z) ? raw - z : raw;
    const flagVal = flagsArr ? flagsArr[i] : 0;
    if (flagVal !== 0) flaggedPixels++;

    signal[i] = val;
    if (Number.isFinite(val)) {
      validValues.push(val);
    }
  }

  if (validValues.length === 0) {
    throw new FitsValidationError(
      'SPHEREx science image contains no valid finite pixels.',
      'INVALID_FITS',
      false
    );
  }

  const sorted = [...validValues].sort((a, b) => a - b);
  const quantile = (q: number) =>
    sorted[Math.min(sorted.length - 1, Math.max(0, Math.floor(q * (sorted.length - 1))))];

  const p1 = quantile(0.02);
  const median = quantile(0.5);
  const p99 = quantile(0.992);
  const minVal = sorted[0];
  const maxVal = sorted[sorted.length - 1];

  const scale = Math.max(1, Math.min(6, Math.floor(320 / Math.max(width, height))));
  const outW = width * scale;
  const outH = height * scale;
  const rgb = new Uint8Array(outW * outH * 3);

  const low = p1;
  const high = Math.max(p99, low + 1e-6);
  const span = high - low;

  for (let py = 0; py < height; py++) {
    const pngBaseY = (height - 1 - py) * scale;
    for (let px = 0; px < width; px++) {
      const val = signal[py * width + px];
      let norm = 0;
      if (Number.isFinite(val)) {
        const linear = Math.min(1, Math.max(0, (val - low) / span));
        if (stretch === 'linear') {
          norm = linear;
        } else if (stretch === 'log') {
          norm = Math.log10(1 + 99 * linear) / Math.log10(100);
        } else {
          const softness = 0.08;
          norm = Math.asinh(linear / softness) / Math.asinh(1 / softness);
        }
      }
      const [r, g, b] = applyColormap(norm, colormap);
      for (let sy = 0; sy < scale; sy++) {
        for (let sx = 0; sx < scale; sx++) {
          const idx = ((pngBaseY + sy) * outW + (px * scale + sx)) * 3;
          rgb[idx] = r;
          rgb[idx + 1] = g;
          rgb[idx + 2] = b;
        }
      }
    }
  }

  const pngBuf = encodeRgbPng(outW, outH, rgb);
  const pngDataUrl = `data:image/png;base64,${pngBuf.toString('base64')}`;

  const hm = imageHdu.headerMap;
  const crval1 = hm.has('CRVAL1') ? Number(hm.get('CRVAL1')) : null;
  const crval2 = hm.has('CRVAL2') ? Number(hm.get('CRVAL2')) : null;
  const crpix1 = hm.has('CRPIX1') ? Number(hm.get('CRPIX1')) : null;
  const crpix2 = hm.has('CRPIX2') ? Number(hm.get('CRPIX2')) : null;
  const pc11 = hm.has('PC1_1') ? Number(hm.get('PC1_1')) : null;
  const pc12 = hm.has('PC1_2') ? Number(hm.get('PC1_2')) : null;
  const pc21 = hm.has('PC2_1') ? Number(hm.get('PC2_1')) : null;
  const pc22 = hm.has('PC2_2') ? Number(hm.get('PC2_2')) : null;
  const pcMatrix: [number, number, number, number] | null =
    pc11 !== null && pc12 !== null && pc21 !== null && pc22 !== null
      ? [pc11, pc12, pc21, pc22]
      : null;

  const headers: FitsHeaderSummary = {
    dateObs: hm.get('DATE-OBS') || null,
    mjdObs: hm.has('MJD-OBS') ? Number(hm.get('MJD-OBS')) : null,
    mjdAvg: hm.has('MJD-AVG') ? Number(hm.get('MJD-AVG')) : null,
    detector: hm.has('DETECTOR') ? Number(hm.get('DETECTOR')) : null,
    bunit: hm.get('BUNIT') || 'MJy / sr',
    spsFlags: hm.get('HIERARCH SPS_FLAGS') || null,
    obsInSband: hm.get('HIERARCH OBS_IN_SBAND') || null,
    minGcd2SaaDeg: hm.has('HIERARCH SGT_MIN_GCD2SAA')
      ? Number(hm.get('HIERARCH SGT_MIN_GCD2SAA'))
      : null,
    ctype1: hm.get('CTYPE1') || null,
    ctype2: hm.get('CTYPE2') || null,
    crval1,
    crval2,
    crpix1,
    crpix2,
    pcMatrix,
    hduNames: cached.hdus.map((h) => h.extname),
  };

  let targetPixelX: number | null = null;
  let targetPixelY: number | null = null;
  if (crval1 !== null && crval2 !== null && crpix1 !== null && crpix2 !== null && pcMatrix) {
    const pxPos = worldToPixel(params.raDeg, params.decDeg, crval1, crval2, crpix1, crpix2, pcMatrix);
    if (pxPos && pxPos.x >= 0 && pxPos.x < width && pxPos.y >= 0 && pxPos.y < height) {
      targetPixelX = Number(pxPos.x.toFixed(2));
      targetPixelY = Number(pxPos.y.toFixed(2));
    }
  }

  const cx = targetPixelX !== null ? targetPixelX : width / 2;
  const cy = targetPixelY !== null ? targetPixelY : height / 2;
  const apRadius = 2.0;

  let peak = -Infinity;
  let sumRaw = 0;
  let sumZodi = 0;
  let sumVar = 0;
  let apCount = 0;
  let varCount = 0;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const dist = Math.hypot(x - cx, y - cy);
      if (dist <= apRadius) {
        const idx = y * width + x;
        const val = imageArr[idx];
        const isFlagged = flagsArr ? flagsArr[idx] !== 0 : false;
        if (Number.isFinite(val)) {
          if (val > peak) peak = val;
          sumRaw += val;
          sumZodi += zodiArr && Number.isFinite(zodiArr[idx]) ? zodiArr[idx] : 0;
          if (
            varArr &&
            !isFlagged &&
            Number.isFinite(varArr[idx]) &&
            varArr[idx] >= 0 &&
            varArr[idx] < 1e12
          ) {
            sumVar += varArr[idx];
            varCount++;
          }
          apCount++;
        }
      }
    }
  }

  const meanRaw = apCount > 0 ? sumRaw / apCount : null;
  const meanZodi = apCount > 0 && zodiArr ? sumZodi / apCount : null;
  const netSurfaceBrightness =
    meanRaw !== null && meanZodi !== null ? meanRaw - meanZodi : meanRaw;
  const uncertaintySigma =
    apCount > 0 && varArr && varCount > 0
      ? Math.sqrt(Math.max(0, sumVar * (apCount / varCount))) / apCount
      : null;

  const photometry: FitsPhotometrySummary = {
    targetPixelX,
    targetPixelY,
    apertureRadiusPx: apRadius,
    peakSurfaceBrightness: Number.isFinite(peak) ? Number(peak.toFixed(5)) : null,
    apertureMeanSurfaceBrightness: meanRaw !== null ? Number(meanRaw.toFixed(5)) : null,
    zodiMeanBackground: meanZodi !== null ? Number(meanZodi.toFixed(5)) : null,
    netSurfaceBrightness:
      netSurfaceBrightness !== null ? Number(netSurfaceBrightness.toFixed(5)) : null,
    uncertaintySigma: uncertaintySigma !== null ? Number(uncertaintySigma.toFixed(5)) : null,
    unit: headers.bunit || 'MJy / sr',
    flaggedPixelFraction: Number((flaggedPixels / (width * height)).toFixed(4)),
    note:
      targetPixelX !== null
        ? 'Aperture measured around WCS-projected target coordinate within r = 2 px.'
        : 'Aperture measured around cutout center (WCS target projection fell outside cutout bounds).',
  };

  const stats: FitsStats = {
    width,
    height,
    min: Number(minVal.toFixed(5)),
    max: Number(maxVal.toFixed(5)),
    median: Number(median.toFixed(5)),
    p1: Number(p1.toFixed(5)),
    p99: Number(p99.toFixed(5)),
    validPixels: validValues.length,
    totalPixels: width * height,
    zodiSubtracted: subtractZodi && zodiArr !== null,
    stretch,
    colormap,
  };

  const rawHeaderCards = imageHdu.cards
    .map((c) => c.trimEnd())
    .filter((c) => c.length > 0 && !c.startsWith('END'));

  const result: FitsInspectResponse = {
    dataSource: 'NASA/IPAC IRSA SPHEREx MEF',
    cutoutUrl,
    pngDataUrl,
    headers,
    stats,
    photometry,
    rawHeaderCards,
  };

  if (inspectCache.size >= MAX_INSPECT_CACHE) {
    const oldestKey = inspectCache.keys().next().value;
    if (oldestKey) inspectCache.delete(oldestKey);
  }
  inspectCache.set(inspectKey, result);

  return result;
}
