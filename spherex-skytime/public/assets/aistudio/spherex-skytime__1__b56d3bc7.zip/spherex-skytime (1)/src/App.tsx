import { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { FeaturedGalleryModal } from './components/FeaturedGalleryModal.tsx';
import { SkyExplorer } from './components/SkyExplorer.tsx';
import { MissionSections } from './components/MissionSections.tsx';
import type { ChallengeTarget, FeaturedObservation } from './types/spherex.ts';

interface FeaturedApiResponse {
  dateKey: string;
  localDate?: string;
  matchedLocalDate?: boolean;
  featuredIndex: number;
  items: FeaturedObservation[];
  isFallback: boolean;
}

function getLocalDateParams(): { localDate: string; tzOffsetMin: number } {
  const now = new Date();
  const localDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
    now.getDate()
  ).padStart(2, '0')}`;
  return { localDate, tzOffsetMin: now.getTimezoneOffset() };
}

export default function App() {
  const [featuredData, setFeaturedData] = useState<FeaturedApiResponse | null>(null);
  const [featuredLoading, setFeaturedLoading] = useState(true);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [targets, setTargets] = useState<ChallengeTarget[]>([]);
  const [isAladinFullscreen, setIsAladinFullscreen] = useState(false);
  const [externalLoadRequest, setExternalLoadRequest] = useState<{
    raInput: string;
    decInput: string;
    label?: string;
    preferObsId?: string;
    nonce: number;
  } | null>(null);

  useEffect(() => {
    const handler = (ev: Event) => {
      const detail = (ev as CustomEvent<{ fullscreen?: boolean }>).detail;
      setIsAladinFullscreen(Boolean(detail?.fullscreen));
    };
    window.addEventListener('spherex:aladin-fullscreen', handler);
    return () => window.removeEventListener('spherex:aladin-fullscreen', handler);
  }, []);

  useEffect(() => {
    let cancelled = false;

    const safeJson = async <T,>(url: string): Promise<T | null> => {
      try {
        const r = await fetch(url);
        const text = await r.text();
        if (!r.ok || text.trimStart().startsWith('<')) return null;
        return JSON.parse(text) as T;
      } catch {
        return null;
      }
    };

    safeJson<{ targets?: ChallengeTarget[] }>('/api/targets').then((d) => {
      if (!cancelled && d && Array.isArray(d.targets)) setTargets(d.targets);
    });

    const { localDate, tzOffsetMin } = getLocalDateParams();
    const qs = new URLSearchParams({
      localDate,
      tzOffsetMin: String(tzOffsetMin),
    });

    safeJson<FeaturedApiResponse>(`/api/featured?${qs.toString()}`)
      .then((d) => {
        if (!cancelled && d && Array.isArray(d.items)) {
          setFeaturedData(d);
        }
      })
      .finally(() => {
        if (!cancelled) setFeaturedLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleLoadFeaturedInExplorer = (item: FeaturedObservation) => {
    setExternalLoadRequest({
      raInput: item.observation.raHms,
      decInput: item.observation.decDms,
      label: item.title,
      preferObsId: item.observation.obsId,
      nonce: Date.now(),
    });
    scrollToSection('explore');
  };

  const featuredItem =
    featuredData && featuredData.items.length > 0
      ? featuredData.items[featuredData.featuredIndex] || featuredData.items[0]
      : null;

  return (
    <div className="min-h-screen bg-[#060A14] text-slate-100">
      {!isAladinFullscreen && <Navbar onNavigate={scrollToSection} />}

      <main>
        <HeroSection
          featured={featuredItem}
          featuredLoading={featuredLoading}
          matchedLocalDate={Boolean(featuredData?.matchedLocalDate)}
          localDate={featuredData?.localDate || ''}
          onStartExploring={() => scrollToSection('explore')}
          onDiscoverMission={() => scrollToSection('about')}
          onOpenGallery={() => setGalleryOpen(true)}
          onLoadFeaturedInExplorer={handleLoadFeaturedInExplorer}
        />

        <SkyExplorer targets={targets} externalLoadRequest={externalLoadRequest} />

        <MissionSections />
      </main>

      <FeaturedGalleryModal
        open={galleryOpen}
        items={featuredData?.items || []}
        featuredIndex={featuredData?.featuredIndex || 0}
        dateKey={featuredData?.localDate || featuredData?.dateKey || ''}
        matchedLocalDate={Boolean(featuredData?.matchedLocalDate)}
        onClose={() => setGalleryOpen(false)}
        onSelectInExplorer={handleLoadFeaturedInExplorer}
      />
    </div>
  );
}
